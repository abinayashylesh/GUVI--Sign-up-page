

<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "guvi_task";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get user input from the signup form
$first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
$last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
$bday = mysqli_real_escape_string($conn, $_POST['bday']);
$number = mysqli_real_escape_string($conn, $_POST['number']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

// Hash the password for security
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert user data into the database
$sql = "INSERT INTO users (first_name, last_name, bday, number, email, password) VALUES ('$first_name', '$last_name', '$bday', '$number', '$email', '$password')";

if (mysqli_query($conn, $sql)) {
    echo "Registration successful. Please log in.";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>